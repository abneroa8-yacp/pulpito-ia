"use client";

import { DevotionalRequest } from "./types";

type Props = {
  data: DevotionalRequest;
  onChange: (data: DevotionalRequest) => void;
};

export default function DevocionalesForm({
  data,
  onChange,
}: Props) {
  function update<K extends keyof DevotionalRequest>(
    field: K,
    value: DevotionalRequest[K]
  ) {
    onChange({
      ...data,
      [field]: value,
    });
  }

  return (
    <div className="space-y-6">

      {/* Tipo */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          ❤️ Tipo de Devocional
        </label>

        <select
          value={data.tipo}
          onChange={(e) => update("tipo", e.target.value)}
   className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white placeholder:text-slate-400 focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>🌅 Devocional del Día</option>
          <option>📅 Serie de 7 Días</option>
          <option>📖 Serie de 30 Días</option>
          <option>📚 Serie de 365 Días</option>
          <option>👨 Para Varones</option>
          <option>👩 Para Mujeres</option>
          <option>👥 Para Jóvenes</option>
          <option>👨‍👩‍👧 Familiar</option>
          <option>🎯 Por Tema</option>
        </select>
      </div>

      {/* Tema */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          📖 Tema o Pasaje
        </label>

        <input
          value={data.tema}
          onChange={(e) => update("tema", e.target.value)}
          placeholder="Ejemplo: Salmo 23"
         className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white placeholder:text-slate-400 focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        />
      </div>

      {/* Objetivo */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          🎯 Objetivo
        </label>

        <input
          value={data.objetivo}
          onChange={(e) => update("objetivo", e.target.value)}
          placeholder="¿Qué deseas lograr con este devocional?"
  className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white placeholder:text-slate-400 focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        />
      </div>

      {/* Audiencia */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          👥 Audiencia
        </label>

        <select
          value={data.audiencia}
          onChange={(e) => update("audiencia", e.target.value)}
className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white placeholder:text-slate-400 focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>General</option>
          <option>Nuevos creyentes</option>
          <option>Jóvenes</option>
          <option>Matrimonios</option>
          <option>Mujeres</option>
          <option>Varones</option>
          <option>Líderes</option>
          <option>Pastores</option>
        </select>
      </div>

      {/* Tiempo */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          ⏱️ Tiempo de lectura
        </label>

        <select
          value={data.tiempo}
          onChange={(e) => update("tiempo", e.target.value)}
className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white placeholder:text-slate-400 focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>5 minutos</option>
          <option>10 minutos</option>
          <option>15 minutos</option>
          <option>20 minutos</option>
        </select>
      </div>

      {/* Versión */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          📖 Versión Bíblica
        </label>

        <select
          value={data.version}
          onChange={(e) => update("version", e.target.value)}
className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white placeholder:text-slate-400 focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>RVR1960</option>
          <option>NTV</option>
          <option>NVI</option>
          <option>NBLA</option>
        </select>
      </div>

      {/* Tono */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          🎨 Tono
        </label>

        <select
          value={data.tono}
          onChange={(e) => update("tono", e.target.value)}
className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white placeholder:text-slate-400 focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>Devocional</option>
          <option>Pastoral</option>
          <option>Inspirador</option>
          <option>Académico</option>
        </select>
      </div>

    </div>
  );
}