"use client";

import { useState } from "react";

import DevocionalesForm from "./DevocionalesForm";
import ResultViewer from "@/components/common/ResultViewer";
import { DevotionalRequest } from "./types";
import { saveDocument } from "@/lib/storage/library";

export default function DevocionalesWorkspace() {
  const [data, setData] = useState<DevotionalRequest>({
    tipo: "🌅 Devocional del Día",
    tema: "",
    objetivo: "",
    audiencia: "General",
    tiempo: "10 minutos",
    version: "RVR1960",
    tono: "Devocional",
  });

  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState("");

async function generarDevocional() {

  if (!data.tema.trim()) {
    alert("Escribe un tema o un pasaje bíblico.");
    return;
  }

  setLoading(true);

    try {
      const res = await fetch("/api/sermon/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          tipo: "devocional",
        }),
      });

      console.log("STATUS:", res.status);
console.log("OK:", res.ok);
      const json = await res.json();
      console.log("RESPUESTA:", json);

const contenido =
  json.result ||
  json.sermon ||
  json.error ||
  "No hubo respuesta.";

setResultado(contenido);

if (json.result || json.sermon) {
  saveDocument({
    title: data.tema,
    type: "devocional",
    content: contenido,
  });
}
    } catch (error) {
      console.error(error);
      setResultado("❌ Error al conectar con la IA.");
    } finally {
      setLoading(false);
    }
  }
return (
  <div className="mt-8 space-y-8">
    <h1 className="text-4xl font-bold text-white">
      ❤️ Devocionales
    </h1>

    <DevocionalesForm
      data={data}
      onChange={setData}
    />

    <div className="flex flex-wrap gap-4">

      <button
        onClick={generarDevocional}
        disabled={loading}
        className="bg-green-600 hover:bg-green-700 disabled:bg-slate-700 disabled:cursor-not-allowed rounded-xl px-8 py-4 font-bold text-white transition"
      >
        {loading ? "⏳ Generando..." : "❤️ Generar Devocional"}
      </button>

      <button
        onClick={generarDevocional}
        disabled={loading || !resultado}
        className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 disabled:cursor-not-allowed rounded-xl px-8 py-4 font-bold text-white transition"
      >
        🔄 Regenerar
      </button>

      <button
        onClick={() => {
          setResultado("");

          setData({
            tipo: "🌅 Devocional del Día",
            tema: "",
            objetivo: "",
            audiencia: "General",
            tiempo: "10 minutos",
            version: "RVR1960",
            tono: "Devocional",
          });
        }}
        className="bg-slate-700 hover:bg-slate-600 rounded-xl px-8 py-4 font-bold text-white transition"
      >
        🆕 Nuevo Devocional
      </button>

    </div>

    <ResultViewer
      loading={loading}
      title="Devocional"
      content={resultado}
    />
  </div>
);
}