"use client";

import { useState } from "react";
import EstudiosForm from "./EstudiosForm";
import { SermonRequest } from "./types";
import ResultViewer from "@/components/common/ResultViewer";
import { saveDocument } from "@/lib/storage/library";

export default function EstudiosWorkspace() {
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState("");

  async function generar(data: SermonRequest) {
    setLoading(true);

    try {
      const res = await fetch("/api/sermon/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          tipo: "estudio",
        }),
      });

const json = await res.json();

const contenido =
  json.result ||
  json.sermon ||
  json.error ||
  "No hubo respuesta.";

setResultado(contenido);

if (json.result || json.sermon) {
  saveDocument({
    title: data.tema,
    type: "estudio",
    content: contenido,
  });
}
    } catch {
      setResultado("❌ Error al generar el estudio.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <EstudiosForm
        tipo="estudio"
        onGenerate={generar}
      />

      <ResultViewer
        loading={loading}
        title="Estudio Bíblico"
        content={resultado}
      />
    </>
  );
}