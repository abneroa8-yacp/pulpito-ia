"use client";

import { useState } from "react";
import { SermonRequest } from "./types";

type Props = {
  tipo: string;
  onGenerate: (data: SermonRequest) => void;
};

export default function EstudiosForm({
  tipo,
  onGenerate,
}: Props) {

  const [tema, setTema] = useState("");
  const [objetivo, setObjetivo] = useState("");
  const [audiencia, setAudiencia] = useState("Iglesia General");
  const [duracion, setDuracion] = useState("45 minutos");
  const [version, setVersion] = useState("RVR1960");
  const [tono, setTono] = useState("Pastoral");

  const tituloCampo =
    tipo === "tematico"
      ? "Tema"
      : tipo === "evangelistico"
      ? "Tema Evangelístico"
      : "Pasaje Bíblico";

  const placeholder =
    tipo === "tematico"
      ? "Ej. La fe que vence al mundo"
      : tipo === "evangelistico"
      ? "Ej. Cristo salva"
      : "Ej. Romanos 8:1-17";

  function generar() {
    if (!tema.trim()) {
      alert("Escribe un tema o un pasaje bíblico.");
      return;
    }

    onGenerate({
      tipo,
      tema,
      objetivo,
      audiencia,
      duracion,
      version,
      tono,
    });
  }

  return (
    <div className="mt-10 rounded-2xl border border-slate-800 bg-slate-900 p-8">

      <h2 className="text-3xl font-bold text-white">
  {tipo === "estudio"
    ? "Configuración del Estudio Bíblico"
    : "Configuración del Sermón"}
</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">

        <div className="md:col-span-2">
          <label className="block text-slate-300 mb-2">
            {tituloCampo}
          </label>

          <input
            value={tema}
            onChange={(e) => setTema(e.target.value)}
            placeholder={placeholder}
            className="w-full rounded-xl bg-slate-950 border border-slate-700 p-4 text-white"
          />
        </div>

        <div>
          <label className="block text-slate-300 mb-2">
            Objetivo
          </label>

          <input
            value={objetivo}
            onChange={(e) => setObjetivo(e.target.value)}
           placeholder="¿Qué deseas lograr con el estudio bíblico?"
            className="w-full rounded-xl bg-slate-950 border border-slate-700 p-4 text-white"
          />
        </div>

        <div>
          <label className="block text-slate-300 mb-2">
            Audiencia
          </label>

          <select
            value={audiencia}
            onChange={(e) => setAudiencia(e.target.value)}
            className="w-full rounded-xl bg-slate-950 border border-slate-700 p-4 text-white"
          >
            <option>Iglesia General</option>
            <option>Jóvenes</option>
            <option>Niños</option>
            <option>Matrimonios</option>
            <option>Líderes</option>
            <option>Evangelístico</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-300 mb-2">
            Duración
          </label>

          <select
            value={duracion}
            onChange={(e) => setDuracion(e.target.value)}
            className="w-full rounded-xl bg-slate-950 border border-slate-700 p-4 text-white"
          >
            <option>15 minutos</option>
            <option>30 minutos</option>
            <option>45 minutos</option>
            <option>60 minutos</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-300 mb-2">
            Versión Bíblica
          </label>

          <select
            value={version}
            onChange={(e) => setVersion(e.target.value)}
            className="w-full rounded-xl bg-slate-950 border border-slate-700 p-4 text-white"
          >
            <option>RVR1960</option>
            <option>NVI</option>
            <option>NBLA</option>
            <option>DHH</option>
            <option>NTV</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-300 mb-2">
            Tono
          </label>

          <select
            value={tono}
            onChange={(e) => setTono(e.target.value)}
            className="w-full rounded-xl bg-slate-950 border border-slate-700 p-4 text-white"
          >
            <option>Pastoral</option>
            <option>Inspirador</option>
            <option>Académico</option>
            <option>Evangelístico</option>
          </select>
        </div>

      </div>

    <button
  onClick={generar}
  className="mt-8 rounded-xl bg-green-600 hover:bg-green-700 px-8 py-4 font-bold text-white transition"
>
  {tipo === "estudio"
    ? "Generar Estudio Bíblico"
    : "Generar Sermón"}
</button>

    </div>
  );
}