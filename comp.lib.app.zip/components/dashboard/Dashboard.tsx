import Link from "next/link";
import AppLayout from "@/components/layout/AppLayout";

export default function Dashboard() {
  return (
    <AppLayout>
      <div className="max-w-7xl">

        <h1 className="text-5xl font-bold text-white">
          👋 Bienvenido a Púlpito IA
        </h1>

        <p className="text-slate-400 mt-3 text-lg">
          ¿Qué deseas preparar hoy?
        </p>

        <input
          placeholder="Buscar sermones, estudios, exégesis..."
          className="
            w-full
            mt-8
            bg-slate-900
            border
            border-slate-800
            rounded-2xl
            p-5
            text-white
            outline-none
            focus:border-green-500
          "
        />

        <h2 className="text-white text-2xl font-bold mt-12 mb-6">
          ⚡ Accesos rápidos
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">

          <Card title="🎙 Sermones" href="/sermones" />
          <Card title="📖 Estudios" href="/estudios" />
          <Card title="📜 Exégesis" href="/exegesis" />
          <Card title="🇬🇷 Griego" href="/griego" />
          <Card title="🇮🇱 Hebreo" href="/hebreo" />
          <Card title="❤️ Devocionales" href="/devocionales" />
          <Card title="💡 Ilustraciones" href="/ilustraciones" />
          <Card title="📚 Biblioteca" href="/biblioteca" />

        </div>

      </div>
    </AppLayout>
  );
}

function Card({
  title,
  href,
}: {
  title: string;
  href: string;
}) {
  return (
    <Link
      href={href}
      className="
        bg-slate-900
        hover:bg-slate-800
        border
        border-slate-800
        hover:border-green-500
        rounded-2xl
        p-8
        text-white
        transition
        text-left
        block
      "
    >
      <h3 className="text-xl font-semibold">
        {title}
      </h3>
    </Link>
  );
}