"use client";

import { useState } from "react";
import HebreoForm from "./HebreoForm";
import { HebrewRequest } from "./types";
import ResultViewer from "@/components/common/ResultViewer";
import { saveDocument } from "@/lib/storage/library";

export default function HebreoWorkspace() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");

  const [data, setData] = useState<HebrewRequest>({
    palabra: "",
    version: "RVR1960",
    nivel: "Intermedio",
    incluirStrong: true,
    incluirMorfologia: true,
  });

  async function generar() {
    try {
      setLoading(true);

      const res = await fetch("/api/sermon/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
   body: JSON.stringify({
  ...data,
  tipo: "hebreo",
})
      });

      const json = await res.json();

      if (!res.ok) {
        throw new Error(json.error || "Ocurrió un error.");
      }

const contenido =
  json.result ||
  json.sermon ||
  json.error ||
  "No hubo respuesta.";

setResult(contenido);

if (res.ok && (json.result || json.sermon)) {
  saveDocument({
    title: data.palabra,
    type: "hebreo",
    content: contenido,
  });
}
    } catch (error) {
      console.error(error);
      setResult("❌ Ocurrió un error al generar el análisis.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <HebreoForm
        value={data}
        onChange={setData}
      />

      <button
        onClick={generar}
        disabled={loading}
        className="rounded-xl bg-blue-600 px-6 py-3 text-white hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? "Analizando..." : "🇮🇱 Analizar Hebreo"}
      </button>

      <ResultViewer
        loading={loading}
        content={result}
        title="Hebreo Bíblico"
      />
    </div>
  );
}