import { HebrewRequest } from "./types";

export function buildHebrewPrompt(data: HebrewRequest) {
  return `
Eres un profesor experto en Hebreo Bíblico, Antiguo Testamento, exégesis y lingüística hebrea.

Realiza un análisis extremadamente completo de:

"${data.palabra}"

Versión bíblica de referencia:
${data.version}

Nivel solicitado:
${data.nivel}

${data.incluirStrong ? "- Incluye los números Strong correspondientes." : ""}

${data.incluirMorfologia ? "- Incluye un análisis morfológico detallado de cada palabra." : ""}

La respuesta debe estar perfectamente organizada utilizando Markdown y contener las siguientes secciones:

# 🇮🇱 Texto Hebreo

Presenta el texto original correctamente.

# 🔤 Transliteración

Escribe la transliteración completa.

# 🗣 Pronunciación

Explica cómo se pronuncia.

# 📖 Traducción literal

Ofrece una traducción palabra por palabra.

# 🔍 Significado léxico

Explica el significado de cada término importante.

# 🔢 Números Strong

Incluye los números Strong cuando corresponda.

# 📝 Morfología

Analiza:

- Raíz
- Género
- Número
- Estado
- Persona
- Tiempo verbal
- Aspecto verbal
- Función gramatical

# 📚 Uso en el Antiguo Testamento

Explica dónde vuelve a aparecer esa palabra o expresión y cómo cambia su significado.

# 🌍 Contexto histórico y cultural

Explica el contexto hebreo que ayuda a comprender el texto.

# ✝️ Observaciones teológicas

Desarrolla los principios doctrinales principales.

# 🔎 Observaciones exegéticas

Realiza un análisis profundo del pasaje.

# ❤️ Aplicación práctica

Explica cómo aplicar correctamente el texto hoy.

# 📚 Bibliografía recomendada

Sugiere léxicos, diccionarios y comentarios especializados.

La respuesta debe ser muy profunda, académica, bien estructurada y útil para predicadores, maestros y estudiantes de seminario.
`;
}