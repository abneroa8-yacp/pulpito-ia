"use client";

import { HebrewRequest } from "./types";

interface Props {
  value: HebrewRequest;
  onChange: (data: HebrewRequest) => void;
}

export default function HebreoForm({ value, onChange }: Props) {
  return (
    <div className="space-y-6">

      <div>
        <label className="block mb-2 font-medium text-white">
          🇮🇱 Palabra o Pasaje
        </label>

        <input
          type="text"
          value={value.palabra}
          onChange={(e) =>
            onChange({
              ...value,
              palabra: e.target.value,
            })
          }
          placeholder="Ej. בְּרֵאשִׁית o Génesis 1:1"
          className="w-full rounded-xl border border-slate-700 bg-slate-800 p-3 text-white placeholder:text-slate-400 focus:border-cyan-500 focus:outline-none"
        />
      </div>

      <div>
        <label className="block mb-2 font-medium text-white">
          📖 Versión Bíblica
        </label>

        <input
          type="text"
          value={value.version}
          onChange={(e) =>
            onChange({
              ...value,
              version: e.target.value,
            })
          }
          placeholder="RVR1960"
          className="w-full rounded-xl border border-slate-700 bg-slate-800 p-3 text-white placeholder:text-slate-400 focus:border-cyan-500 focus:outline-none"
        />
      </div>

      <div>
        <label className="block mb-2 font-medium text-white">
          🎓 Nivel de profundidad
        </label>

        <select
          value={value.nivel}
          onChange={(e) =>
            onChange({
              ...value,
              nivel: e.target.value,
            })
          }
          className="w-full rounded-xl border border-slate-700 bg-slate-800 p-3 text-white focus:border-cyan-500 focus:outline-none"
        >
          <option>Básico</option>
          <option>Intermedio</option>
          <option>Avanzado</option>
        </select>
      </div>

      <div className="space-y-3 rounded-xl border border-slate-700 bg-slate-900 p-4">

        <label className="flex items-center gap-3 text-white">
          <input
            type="checkbox"
            className="accent-cyan-500"
            checked={value.incluirStrong}
            onChange={(e) =>
              onChange({
                ...value,
                incluirStrong: e.target.checked,
              })
            }
          />
          Incluir números Strong
        </label>

        <label className="flex items-center gap-3 text-white">
          <input
            type="checkbox"
            className="accent-cyan-500"
            checked={value.incluirMorfologia}
            onChange={(e) =>
              onChange({
                ...value,
                incluirMorfologia: e.target.checked,
              })
            }
          />
          Incluir morfología hebrea
        </label>

      </div>

    </div>
  );
}