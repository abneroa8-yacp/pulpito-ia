"use client";

const modules = [
  "📖 Sermones",
  "📚 Estudios Bíblicos",
  "📝 Bosquejos",
  "❤️ Devocionales",
  "🎓 Clases Bíblicas",
  "💡 Ilustraciones",
  "❓ Preguntas Bíblicas",
  "📜 Exégesis",
  "🏛 Contexto Histórico",
];

export default function Sidebar() {
  return (
    <aside
      style={{
        width: "280px",
        background: "#111827",
        color: "white",
        padding: "24px",
        display: "flex",
        flexDirection: "column",
        gap: "12px",
      }}
    >
      <h2
        style={{
          fontSize: "24px",
          marginBottom: "20px",
        }}
      >
        📚 Púlpito IA
      </h2>

      {modules.map((module) => (
        <button
          key={module}
          style={{
            background: "#1f2937",
            color: "white",
            border: "none",
            padding: "14px",
            borderRadius: "10px",
            textAlign: "left",
            cursor: "pointer",
            fontSize: "15px",
          }}
        >
          {module}
        </button>
      ))}
    </aside>
  );
}