"use client";

import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import ExportButtons from "@/components/export/ExportButtons";

type Props = {
  role: "user" | "assistant";
  text: string;
};

export default function MessageBubble({ role, text }: Props) {
  const isUser = role === "user";

  return (
    <div
      style={{
        display: "flex",
        justifyContent: isUser ? "flex-end" : "flex-start",
      }}
    >
      <div
        style={{
          maxWidth: "80%",
          padding: "18px",
          borderRadius: "16px",
          background: isUser ? "#22c55e" : "#1f2937",
          color: "white",
          lineHeight: 1.8,
          overflowWrap: "break-word",
        }}
      >
        {isUser ? (
          text
        ) : (
          <>
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {text}
            </ReactMarkdown>

            <ExportButtons text={text} />
          </>
        )}
      </div>
    </div>
  );
}