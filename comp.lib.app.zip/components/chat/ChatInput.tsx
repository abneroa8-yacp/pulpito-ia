"use client";

import { useState } from "react";

type Props = {
  onSend: (message: string) => void;
};

export default function ChatInput({ onSend }: Props) {
  const [mensaje, setMensaje] = useState("");

  const enviar = () => {
    if (!mensaje.trim()) return;

    onSend(mensaje);

    setMensaje("");
  };

  return (
    <div
      style={{
        borderTop: "1px solid #1f2937",
        padding: "20px",
        display: "flex",
        gap: "15px",
        background: "#0b1220",
      }}
    >
      <input
        value={mensaje}
        onChange={(e) => setMensaje(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") enviar();
        }}
        placeholder="Escribe un mensaje..."
        style={{
          flex: 1,
          padding: "16px",
          borderRadius: "12px",
          border: "1px solid #374151",
          background: "#111827",
          color: "white",
          fontSize: "16px",
          outline: "none",
        }}
      />

      <button
        onClick={enviar}
        style={{
          background: "#22c55e",
          color: "white",
          border: "none",
          padding: "0 28px",
          borderRadius: "12px",
          cursor: "pointer",
          fontWeight: "bold",
        }}
      >
        Enviar
      </button>
    </div>
  );
}