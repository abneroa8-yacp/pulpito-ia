"use client";

import MessageBubble from "./MessageBubble";

export type Message = {
  role: "user" | "assistant";
  text: string;
};

type Props = {
  messages: Message[];
  loading: boolean;
};

export default function ChatMessages({
  messages,
  loading,
}: Props) {
  return (
    <section
      style={{
        flex: 1,
        overflowY: "auto",
        padding: "40px",
        display: "flex",
        flexDirection: "column",
        gap: "20px",
      }}
    >
      {messages.map((msg, index) => (
        <MessageBubble
          key={index}
          role={msg.role}
          text={msg.text}
        />
      ))}

      {loading && (
        <MessageBubble
          role="assistant"
          text="✍️ Púlpito IA está escribiendo..."
        />
      )}
    </section>
  );
}