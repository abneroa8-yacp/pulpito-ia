export default function Topbar() {
  return (
    <header className="h-20 border-b border-slate-800 bg-slate-950 flex items-center justify-between px-8">

      <input
        placeholder="Buscar..."
        className="
          w-96
          bg-slate-900
          rounded-xl
          px-5
          py-3
          outline-none
          text-white
        "
      />

      <div className="flex items-center gap-4">

        <button className="bg-green-600 px-4 py-2 rounded-lg">
          Premium
        </button>

        <div className="w-11 h-11 rounded-full bg-slate-700" />

      </div>

    </header>
  );
}