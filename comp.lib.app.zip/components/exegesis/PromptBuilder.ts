import { ExegesisRequest } from "./types";

export function buildExegesisPrompt(data: ExegesisRequest) {
  return `
Actúa como un erudito bíblico, experto en exégesis, hermenéutica, teología sistemática y lenguas bíblicas.

Realiza una exégesis profunda del siguiente pasaje.

## Información

Pasaje: ${data.pasaje}

Versión Bíblica: ${data.version}

Nivel: ${data.nivel}

Audiencia: ${data.audiencia}

Enfoque: ${data.enfoque}

La respuesta debe estar en formato Markdown y desarrollar ampliamente cada apartado.

# 📖 Pasaje

Incluye el texto bíblico utilizando la versión ${data.version}.

# 🏛 Contexto Histórico

- Autor
- Fecha
- Destinatarios
- Situación histórica

# 📚 Contexto Literario

- Género
- Contexto inmediato
- Contexto del libro

# 🌍 Contexto Cultural

Explica las costumbres, tradiciones y aspectos culturales relevantes.

# ✍️ Análisis Gramatical

Analiza las expresiones importantes del texto.

# 🔍 Palabras Clave

Explica las palabras más importantes del pasaje.

# 🧠 Principios Teológicos

Extrae las doctrinas presentes.

# 🔗 Referencias Cruzadas

Incluye referencias relacionadas explicando su conexión.

# ❤️ Aplicación Práctica

Presenta aplicaciones para la vida cristiana actual.

# 📚 Bibliografía Recomendada

Sugiere comentarios bíblicos y autores reconocidos para profundizar el estudio.

Entrega una respuesta clara, organizada, extensa y académicamente sólida.
`;
}