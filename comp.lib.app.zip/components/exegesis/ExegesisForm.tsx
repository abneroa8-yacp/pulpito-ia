"use client";

import { ExegesisRequest } from "./types";

type Props = {
  data: ExegesisRequest;
  onChange: (data: ExegesisRequest) => void;
};

export default function ExegesisForm({
  data,
  onChange,
}: Props) {
  function update<K extends keyof ExegesisRequest>(
    field: K,
    value: ExegesisRequest[K]
  ) {
    onChange({
      ...data,
      [field]: value,
    });
  }

  return (
    <div className="space-y-6">

      {/* Pasaje */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          📖 Pasaje Bíblico
        </label>

        <input
          value={data.pasaje}
          onChange={(e) => update("pasaje", e.target.value)}
          placeholder="Ejemplo: Juan 3:16"
          className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white placeholder:text-slate-400 focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        />
      </div>

      {/* Versión */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          📚 Versión Bíblica
        </label>

        <select
          value={data.version}
          onChange={(e) => update("version", e.target.value)}
          className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>RVR1960</option>
          <option>NVI</option>
          <option>NTV</option>
          <option>NBLA</option>
        </select>
      </div>

      {/* Nivel */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          🎓 Nivel
        </label>

        <select
          value={data.nivel}
          onChange={(e) => update("nivel", e.target.value)}
          className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>Básico</option>
          <option>Intermedio</option>
          <option>Avanzado</option>
          <option>Académico</option>
        </select>
      </div>

      {/* Audiencia */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          👥 Audiencia
        </label>

        <select
          value={data.audiencia}
          onChange={(e) => update("audiencia", e.target.value)}
          className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>General</option>
          <option>Líderes</option>
          <option>Pastores</option>
          <option>Instituto Bíblico</option>
        </select>
      </div>

      {/* Enfoque */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          🎯 Enfoque
        </label>

        <select
          value={data.enfoque}
          onChange={(e) => update("enfoque", e.target.value)}
          className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>Exegético</option>
          <option>Hermenéutico</option>
          <option>Homilético</option>
          <option>Teológico</option>
          <option>Devocional</option>
        </select>
      </div>

    </div>
  );
}