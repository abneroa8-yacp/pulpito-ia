"use client";

import { useState } from "react";

import ExegesisForm from "./ExegesisForm";
import ResultViewer from "@/components/common/ResultViewer";
import { ExegesisRequest } from "./types";
import { saveDocument } from "@/lib/storage/library";

export default function ExegesisWorkspace() {
  const [data, setData] = useState<ExegesisRequest>({
    pasaje: "",
    version: "RVR1960",
    nivel: "Intermedio",
    audiencia: "General",
    enfoque: "Exegético",
  });

  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState("");

  async function generarExegesis() {
    if (!data.pasaje.trim()) {
      alert("Escribe un pasaje bíblico.");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/sermon/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          tipo: "exegesis",
        }),
      });

      const json = await res.json();

const contenido =
  json.result ||
  json.sermon ||
  json.error ||
  "No hubo respuesta.";

setResultado(contenido);

if (json.result || json.sermon) {
  saveDocument({
    title: data.pasaje,
    type: "exegesis",
    content: contenido,
  });
}
    } catch (error) {
      console.error(error);
      setResultado("❌ Error al conectar con la IA.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mt-8 space-y-8">
      <h1 className="text-4xl font-bold text-white">
        📖 Exégesis Bíblica
      </h1>

      <ExegesisForm
        data={data}
        onChange={setData}
      />

      <div className="flex flex-wrap gap-4">

        <button
          onClick={generarExegesis}
          disabled={loading}
          className="bg-green-600 hover:bg-green-700 disabled:bg-slate-700 disabled:cursor-not-allowed rounded-xl px-8 py-4 font-bold text-white transition"
        >
          {loading ? "⏳ Generando..." : "📖 Generar Exégesis"}
        </button>

        <button
          onClick={generarExegesis}
          disabled={loading || !resultado}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 disabled:cursor-not-allowed rounded-xl px-8 py-4 font-bold text-white transition"
        >
          🔄 Regenerar
        </button>

        <button
          onClick={() => {
            setResultado("");

            setData({
              pasaje: "",
              version: "RVR1960",
              nivel: "Intermedio",
              audiencia: "General",
              enfoque: "Exegético",
            });
          }}
          className="bg-slate-700 hover:bg-slate-600 rounded-xl px-8 py-4 font-bold text-white transition"
        >
          🆕 Nueva Exégesis
        </button>

      </div>

      <ResultViewer
        loading={loading}
        title="Exégesis Bíblica"
        content={resultado}
      />
    </div>
  );
}