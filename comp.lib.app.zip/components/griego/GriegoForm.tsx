"use client";

import { GreekRequest } from "./types";

type Props = {
  data: GreekRequest;
  onChange: (data: GreekRequest) => void;
};

export default function GriegoForm({
  data,
  onChange,
}: Props) {
  function update<K extends keyof GreekRequest>(
    field: K,
    value: GreekRequest[K]
  ) {
    onChange({
      ...data,
      [field]: value,
    });
  }

  return (
    <div className="space-y-6">

      {/* Palabra */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          🇬🇷 Palabra griega o pasaje
        </label>

        <input
          value={data.palabra}
          onChange={(e) => update("palabra", e.target.value)}
          placeholder="Ejemplo: ἀγάπη o Juan 3:16"
          className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white placeholder:text-slate-400 focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        />
      </div>

      {/* Versión */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          📚 Versión Bíblica
        </label>

        <select
          value={data.version}
          onChange={(e) => update("version", e.target.value)}
          className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>RVR1960</option>
          <option>NVI</option>
          <option>NTV</option>
          <option>NBLA</option>
        </select>
      </div>

      {/* Nivel */}
      <div>
        <label className="block mb-2 font-semibold text-white">
          🎓 Nivel
        </label>

        <select
          value={data.nivel}
          onChange={(e) => update("nivel", e.target.value)}
          className="w-full rounded-xl bg-slate-800 border border-slate-600 p-3 text-white focus:border-green-500 focus:ring-2 focus:ring-green-500 outline-none"
        >
          <option>Básico</option>
          <option>Intermedio</option>
          <option>Avanzado</option>
          <option>Académico</option>
        </select>
      </div>

      {/* Opciones */}
      <div className="space-y-3">

        <label className="flex items-center gap-3 text-white">
          <input
            type="checkbox"
            checked={data.incluirStrong}
            onChange={(e) =>
              update("incluirStrong", e.target.checked)
            }
          />
          Incluir números Strong
        </label>

        <label className="flex items-center gap-3 text-white">
          <input
            type="checkbox"
            checked={data.incluirMorfologia}
            onChange={(e) =>
              update("incluirMorfologia", e.target.checked)
            }
          />
          Incluir análisis morfológico
        </label>

      </div>

    </div>
  );
}