import { GreekRequest } from "./types";

export function buildGreekPrompt(data: GreekRequest) {
  return `
Actúa como un profesor de griego koiné, experto en exégesis bíblica, lingüística del Nuevo Testamento y teología.

Analiza la siguiente palabra o pasaje:

Palabra o pasaje:
${data.palabra}

Versión Bíblica:
${data.version}

Nivel:
${data.nivel}

${
  data.incluirStrong
    ? "Incluye los números Strong correspondientes."
    : ""
}

${
  data.incluirMorfologia
    ? "Incluye un análisis morfológico completo."
    : ""
}

La respuesta debe estar en formato Markdown y desarrollar ampliamente cada sección.

# 🇬🇷 Texto Griego

Presenta el texto griego correspondiente si aplica.

# 🔤 Transliteración

Incluye la transliteración correcta.

# 🗣 Pronunciación

Explica cómo se pronuncia.

# 📖 Significado

Describe el significado principal y los matices del término.

# 🔢 Número Strong

Inclúyelo únicamente si fue solicitado.

# 📝 Morfología

Inclúyela únicamente si fue solicitada.

# 📚 Uso en el Nuevo Testamento

Menciona dónde aparece y cómo se utiliza.

# 🔍 Observaciones Exegéticas

Explica la importancia del término dentro del contexto bíblico.

# ❤️ Aplicación

Concluye con una aplicación práctica para el estudio y la predicación.

Entrega una respuesta clara, académica y bien estructurada.
`;
}