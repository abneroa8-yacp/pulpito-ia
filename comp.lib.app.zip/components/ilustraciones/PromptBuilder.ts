import { IllustrationRequest } from "./types";

export function buildIllustrationPrompt(data: IllustrationRequest) {
  return `
Eres un predicador, maestro bíblico y comunicador cristiano con amplia experiencia.

Genera una ilustración para apoyar una predicación.

## Información

Tema:
${data.tema}

Pasaje Bíblico:
${data.pasaje || "No especificado"}

Audiencia:
${data.audiencia}

Tipo de ilustración:
${data.tipo}

Longitud:
${data.longitud}

---

La respuesta debe contener exactamente el siguiente formato en Markdown:

# Ilustración

## Título

## Desarrollo

Desarrolla una ilustración clara, interesante y apropiada para la audiencia indicada.

Debe estar alineada con las Escrituras y ayudar a comprender el tema bíblico.

## Aplicación

Explica cómo conectar esta ilustración con la predicación.

## Transición al Sermón

Escribe una transición natural para pasar de la ilustración al mensaje bíblico.

No inventes doctrinas ni contradigas la Biblia.

La ilustración debe ser memorable, útil para predicar y fácil de comunicar.
`;
}