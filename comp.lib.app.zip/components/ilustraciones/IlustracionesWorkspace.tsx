"use client";

import { useState } from "react";

import IlustracionesForm from "./IlustracionesForm";
import ResultViewer from "@/components/common/ResultViewer";
import { saveDocument } from "@/lib/storage/library";

import { IllustrationRequest } from "./types";

export default function IlustracionesWorkspace() {
  const [data, setData] = useState<IllustrationRequest>({
    tema: "",
    pasaje: "",
    audiencia: "General",
    tipo: "Ilustración Bíblica",
    longitud: "Media",
  });

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");

  async function generate() {
    setLoading(true);

    try {
      const res = await fetch("/api/sermon/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          tipo: "ilustracion",
        }),
      });

      const json = await res.json();

      setResult(json.result);

      saveDocument({
        title: data.tema || "Ilustración",
        type: "ilustracion",
        content: json.result,
      });
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <IlustracionesForm
        data={data}
        setData={setData}
        onGenerate={generate}
        loading={loading}
      />

      <ResultViewer
        loading={loading}
        title="Ilustración"
        content={result}
      />
    </>
  );
}