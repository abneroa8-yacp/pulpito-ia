"use client";

import { IllustrationRequest } from "./types";

interface Props {
  data: IllustrationRequest;
  setData: React.Dispatch<React.SetStateAction<IllustrationRequest>>;
  onGenerate: () => void;
  loading: boolean;
}

export default function IlustracionesForm({
  data,
  setData,
  onGenerate,
  loading,
}: Props) {
  return (
    <div className="space-y-4 rounded-xl border p-6 bg-white dark:bg-zinc-900">
      <div>
        <label className="block mb-2 font-medium">Tema</label>
        <input
          type="text"
          value={data.tema}
          onChange={(e) =>
            setData({ ...data, tema: e.target.value })
          }
          placeholder="Ej. La fe, el perdón, la gracia..."
          className="w-full rounded-lg border p-2"
        />
      </div>

      <div>
        <label className="block mb-2 font-medium">
          Pasaje Bíblico (Opcional)
        </label>
        <input
          type="text"
          value={data.pasaje}
          onChange={(e) =>
            setData({ ...data, pasaje: e.target.value })
          }
          placeholder="Ej. Hebreos 11:1-6"
          className="w-full rounded-lg border p-2"
        />
      </div>

      <div>
        <label className="block mb-2 font-medium">Audiencia</label>
        <select
          value={data.audiencia}
          onChange={(e) =>
            setData({ ...data, audiencia: e.target.value })
          }
          className="w-full rounded-lg border p-2"
        >
          <option>General</option>
          <option>Niños</option>
          <option>Jóvenes</option>
          <option>Adultos</option>
          <option>Matrimonios</option>
          <option>Líderes</option>
          <option>Evangelismo</option>
        </select>
      </div>

      <div>
        <label className="block mb-2 font-medium">
          Tipo de Ilustración
        </label>
        <select
          value={data.tipo}
          onChange={(e) =>
            setData({ ...data, tipo: e.target.value })
          }
          className="w-full rounded-lg border p-2"
        >
          <option>Ilustración Bíblica</option>
          <option>Historia Real</option>
          <option>Historia Histórica</option>
          <option>Analogía Cotidiana</option>
          <option>Naturaleza u Objetos</option>
          <option>Introducción Impactante</option>
          <option>Conclusión Memorable</option>
          <option>Aplicación Emocional</option>
          <option>Humor Sano</option>
        </select>
      </div>

      <div>
        <label className="block mb-2 font-medium">Longitud</label>
        <select
          value={data.longitud}
          onChange={(e) =>
            setData({ ...data, longitud: e.target.value })
          }
          className="w-full rounded-lg border p-2"
        >
          <option>Muy Corta</option>
          <option>Corta</option>
          <option>Media</option>
          <option>Larga</option>
        </select>
      </div>

      <button
        onClick={onGenerate}
        disabled={loading}
        className="w-full rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? "Generando..." : "✨ Generar Ilustración"}
      </button>

      <p className="text-sm text-gray-500">
        Las ilustraciones son herramientas para reforzar la enseñanza bíblica y
        deben utilizarse con discernimiento y fidelidad a las Escrituras.
      </p>
    </div>
  );
}