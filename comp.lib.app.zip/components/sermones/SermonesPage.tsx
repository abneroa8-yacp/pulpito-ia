"use client";

import { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

import AppLayout from "@/components/layout/AppLayout";
import SermonForm from "@/components/sermon/SermonForm";
import ResultToolbar from "@/components/common/ResultToolbar";
import { SermonRequest } from "@/components/sermon/types";
import { saveDocument } from "@/lib/storage/library";

export default function SermonesPage() {
  const [tipo, setTipo] = useState("");
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState("");

  async function generar(data: SermonRequest) {
    setLoading(true);

    try {
      const idioma = localStorage.getItem("idioma") || "es";

      const res = await fetch("/api/sermon/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          idioma,
        }),
      });

      const json = await res.json();

      const contenido =
        json.result ||
        json.sermon ||
        json.error ||
        "No hubo respuesta.";

      setResultado(contenido);

      saveDocument({
        title: data.tema,
        type: "sermon",
        content: contenido,
      });
    } catch (error) {
      console.error(error);
      setResultado("❌ Error al conectar con la IA.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AppLayout>
      <div className="max-w-7xl mx-auto">
        <h1 className="text-5xl font-bold text-white">
          🎙 Generador de Sermones
        </h1>

        <p className="text-slate-400 mt-3">
          Selecciona el tipo de sermón que deseas preparar.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mt-10">
          <Card
            titulo="Expositivo"
            descripcion="Basado en un pasaje bíblico."
            activo={tipo === "expositivo"}
            onClick={() => setTipo("expositivo")}
          />

          <Card
            titulo="Temático"
            descripcion="Basado en un tema."
            activo={tipo === "tematico"}
            onClick={() => setTipo("tematico")}
          />

          <Card
            titulo="Textual"
            descripcion="Basado en uno o varios versículos."
            activo={tipo === "textual"}
            onClick={() => setTipo("textual")}
          />

          <Card
            titulo="Evangelístico"
            descripcion="Enfocado en la salvación."
            activo={tipo === "evangelistico"}
            onClick={() => setTipo("evangelistico")}
          />
        </div>

        {tipo && (
          <SermonForm
            tipo={tipo}
            onGenerate={generar}
          />
        )}

        {loading && (
          <div className="mt-8 rounded-xl bg-slate-900 border border-slate-800 p-4 text-green-400">
            ⏳ Generando sermón...
          </div>
        )}

        {resultado && (
          <div className="mt-10 rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden">
            <div className="flex justify-between items-center border-b border-slate-800 px-6 py-4">
              <h2 className="text-xl font-bold text-white">
                📖 Sermón Generado
              </h2>

              <ResultToolbar
                titulo={resultado.match(/^# (.*)$/m)?.[1] || "Sermón"}
                contenido={resultado}
              />
            </div>

            <div id="sermon-content" className="p-8 bg-slate-950">
              <article
                className="prose prose-invert max-w-none
                !text-white
                prose-headings:!text-white
                prose-p:!text-white
                prose-li:!text-white
                prose-strong:!text-yellow-300
                prose-blockquote:!text-cyan-200
                prose-code:!text-pink-300"
              >
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {resultado}
                </ReactMarkdown>
              </article>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

function Card({
  titulo,
  descripcion,
  activo,
  onClick,
}: {
  titulo: string;
  descripcion: string;
  activo: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-2xl border p-6 text-left transition ${
        activo
          ? "bg-green-600 border-green-500"
          : "bg-slate-900 border-slate-800 hover:border-green-500 hover:bg-slate-800"
      }`}
    >
      <h2 className="text-xl font-bold text-white">{titulo}</h2>

      <p className="text-slate-300 mt-3">{descripcion}</p>
    </button>
  );
}