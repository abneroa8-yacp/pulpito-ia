import Link from "next/link";

export default function Home() {
  return (
    <main
      style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg,#081221,#0f172a)",
        color: "white",
        padding: "60px",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <h1
        style={{
          fontSize: "64px",
          color: "#22c55e",
          marginBottom: "15px",
        }}
      >
        📖 Púlpito IA
      </h1>

      <p
        style={{
          fontSize: "24px",
          color: "#cbd5e1",
          marginBottom: "50px",
        }}
      >
        Tu plataforma inteligente para preparar sermones,
        estudios bíblicos y herramientas ministeriales.
      </p>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit,minmax(260px,1fr))",
          gap: "25px",
        }}
      >
        <Link href="/sermones" style={{ textDecoration: "none" }}>
          <div
            style={{
              background: "#111827",
              padding: "30px",
              borderRadius: "15px",
              cursor: "pointer",
              border: "1px solid #22c55e",
            }}
          >
            <h2>📖 Generador de Sermones</h2>

            <p style={{ color: "#cbd5e1" }}>
              Crea sermones completos con inteligencia artificial.
            </p>
          </div>
        </Link>

        <div
          style={{
            background: "#111827",
            padding: "30px",
            borderRadius: "15px",
            opacity: 0.7,
          }}
        >
          <h2>📚 Estudios Bíblicos</h2>

          <p style={{ color: "#cbd5e1" }}>
            Próximamente.
          </p>
        </div>

        <div
          style={{
            background: "#111827",
            padding: "30px",
            borderRadius: "15px",
            opacity: 0.7,
          }}
        >
          <h2>✍️ Bosquejos</h2>

          <p style={{ color: "#cbd5e1" }}>
            Próximamente.
          </p>
        </div>

        <div
          style={{
            background: "#111827",
            padding: "30px",
            borderRadius: "15px",
            opacity: 0.7,
          }}
        >
          <h2>🤖 Más herramientas IA</h2>

          <p style={{ color: "#cbd5e1" }}>
            Muy pronto.
          </p>
        </div>
      </div>
    </main>
  );
}