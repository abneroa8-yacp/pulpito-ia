"use client";

import { useEffect, useState } from "react";

export default function ConfiguracionPage() {
  const [idioma, setIdioma] = useState("es");
  const [tema, setTema] = useState("dark");

  useEffect(() => {
    const idiomaGuardado = localStorage.getItem("idioma");
    const temaGuardado = localStorage.getItem("tema");

    if (idiomaGuardado) setIdioma(idiomaGuardado);
    if (temaGuardado) setTema(temaGuardado);
  }, []);

  useEffect(() => {
    localStorage.setItem("idioma", idioma);
  }, [idioma]);

  useEffect(() => {
    localStorage.setItem("tema", tema);

    if (tema === "dark") {
      document.documentElement.classList.add("dark");
    } else if (tema === "light") {
      document.documentElement.classList.remove("dark");
    } else {
      const oscuro = window.matchMedia("(prefers-color-scheme: dark)").matches;
      document.documentElement.classList.toggle("dark", oscuro);
    }
  }, [tema]);

  return (
    <main className="min-h-screen bg-[#0f172a] text-white p-8">
      <div className="max-w-2xl mx-auto">

        <h1 className="text-3xl font-bold text-green-400 mb-8">
          ⚙️ Configuración
          <a
  href="/"
  style={{
    display: "inline-flex",
    alignItems: "center",
    gap: "8px",
    color: "#22c55e",
    textDecoration: "none",
    fontSize: "16px",
    fontWeight: "bold",
    marginBottom: "20px",
  }}
>
  ← Regresar al inicio
</a>
        </h1>

        {/* Idioma */}
        <div className="bg-slate-800 rounded-2xl border border-slate-700 p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">
            🌐 Idioma
          </h2>

          <div className="space-y-3">
            <button
              onClick={() => setIdioma("es")}
              className={`w-full rounded-xl py-3 transition ${
                idioma === "es"
                  ? "bg-green-600"
                  : "bg-slate-700 hover:bg-slate-600"
              }`}
            >
              🇲🇽 Español
            </button>

            <button
              onClick={() => setIdioma("en")}
              className={`w-full rounded-xl py-3 transition ${
                idioma === "en"
                  ? "bg-green-600"
                  : "bg-slate-700 hover:bg-slate-600"
              }`}
            >
              🇺🇸 English
            </button>
          </div>
        </div>

        {/* Tema */}
        <div className="bg-slate-800 rounded-2xl border border-slate-700 p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">
            🎨 Tema
          </h2>

          <div className="space-y-3">
            <button
              onClick={() => setTema("dark")}
              className={`w-full rounded-xl py-3 transition ${
                tema === "dark"
                  ? "bg-green-600"
                  : "bg-slate-700 hover:bg-slate-600"
              }`}
            >
              🌙 Oscuro
            </button>

            <button
              onClick={() => setTema("light")}
              className={`w-full rounded-xl py-3 transition ${
                tema === "light"
                  ? "bg-green-600"
                  : "bg-slate-700 hover:bg-slate-600"
              }`}
            >
              ☀️ Claro
            </button>

            <button
              onClick={() => setTema("system")}
              className={`w-full rounded-xl py-3 transition ${
                tema === "system"
                  ? "bg-green-600"
                  : "bg-slate-700 hover:bg-slate-600"
              }`}
            >
              ⚙️ Seguir sistema
            </button>
          </div>
        </div>

        {/* Información */}
        <div className="bg-slate-800 rounded-2xl border border-slate-700 p-6">
          <h2 className="text-xl font-semibold mb-3">
            ℹ️ Acerca de
          </h2>

          <p className="text-slate-300">Púlpito IA</p>
          <p className="text-slate-400">Versión 1.0.0</p>
        </div>

      </div>
    </main>
  );
}