"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";

import Sidebar from "@/components/chat/Sidebar";
import ChatMessages, { Message } from "@/components/chat/ChatMessages";
import ChatInput from "@/components/chat/ChatInput";

export default function ChatPage() {
  const searchParams = useSearchParams();

  const modo = searchParams.get("modo") || "general";

  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      text: `👋 Bienvenido a Púlpito IA.

Modo actual: **${modo.toUpperCase()}**

¿Qué deseas preparar hoy?`,
    },
  ]);

  const [loading, setLoading] = useState(false);

  const handleSend = async (message: string) => {
    const userMessage: Message = {
      role: "user",
      text: message,
    };

    setMessages((prev) => [...prev, userMessage]);

    setLoading(true);

    try {
      const res = await fetch("/api/sermon/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          tema: `[${modo}] ${message}`,
        }),
      });

      const data = await res.json();

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text: data.sermon || data.respuesta || "No hubo respuesta.",
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text: "❌ Error al conectar con la IA.",
        },
      ]);
    }

    setLoading(false);
  };

  return (
    <main
      style={{
        display: "flex",
        height: "100vh",
        background: "#070f1f",
      }}
    >
      <Sidebar />

      <section
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <ChatMessages
          messages={messages}
          loading={loading}
        />

        <ChatInput onSend={handleSend} />
      </section>
    </main>
  );
}