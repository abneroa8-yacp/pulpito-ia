import { buildDevotionalPrompt } from "@/components/devocionales/PromptBuilder";
import { buildExegesisPrompt } from "@/components/exegesis/PromptBuilder";
import { buildGreekPrompt } from "@/components/griego/PromptBuilder";
import { buildHebrewPrompt } from "@/components/hebreo/PromptBuilder";
import { buildIllustrationPrompt } from "@/components/ilustraciones/PromptBuilder";

import { generateAIResponse } from "@/lib/ai/generate";
import { buildSermonPrompt } from "@/lib/prompts/sermon";
import { buildStudyPrompt } from "@/lib/prompts/study";

import { saveDocument } from "@/lib/storage/library";

export async function POST(req: Request) {
  try {
    const data = await req.json();
    const idioma = data.idioma || "es";

    console.log("=== DATA ===");
    console.log(data);
    console.log("TIPO:", data.tipo);
    console.log("TEMA:", data.tema);
    console.log("OBJETIVO:", data.objetivo);
    console.log("AUDIENCIA:", data.audiencia);
    console.log("TIEMPO:", data.tiempo);
    console.log("VERSION:", data.version);
    console.log("TONO:", data.tono);

    let prompt = "";

    switch (data.tipo) {
      case "estudio":
        prompt = buildStudyPrompt(data);
        break;

      case "devocional":
        prompt = buildDevotionalPrompt(data);
        break;

      case "exegesis":
        prompt = buildExegesisPrompt(data);
        break;

      case "griego":
        prompt = buildGreekPrompt(data);
        break;

      case "hebreo":
        prompt = buildHebrewPrompt(data);
        break;

      case "ilustracion":
        prompt = buildIllustrationPrompt(data);
        break;

      default:
        prompt = buildSermonPrompt(data);
        break;
    }
const idiomaPrompt =
  idioma === "en"
    ? `
IMPORTANT:
Generate the ENTIRE response in fluent English.

- Write every heading in English.
- Write every explanation in English.
- Write every outline point in English.
- Write every application in English.
- Write every prayer in English.
- Quote Bible verses in English.
`
    : `
IMPORTANTE:

Genera TODA la respuesta en español.

- Todos los títulos en español.
- Todas las explicaciones en español.
- Todos los puntos en español.
- Todas las aplicaciones en español.
- Todas las oraciones en español.
- Cita los versículos en español.
`;

prompt = `${idiomaPrompt}

${prompt}`;
    console.log("=== PROMPT ===");
    console.log(prompt);
    console.log("LONGITUD DEL PROMPT:", prompt.length);

    console.log("ANTES DE OPENAI");

    const respuesta = await generateAIResponse(prompt);

    console.log("DESPUÉS DE OPENAI");

    console.log("LONGITUD RESPUESTA:", respuesta.length);

    console.log("=========== RESPUESTA IA ===========");
    console.log(respuesta);
    console.log("===================================");

    return Response.json({
      result: respuesta,
    });

  } catch (error) {
    console.error("ERROR COMPLETO:");
    console.error(error);

    return Response.json(
      {
        error: String(error),
      },
      {
        status: 500,
      }
    );
  }
}