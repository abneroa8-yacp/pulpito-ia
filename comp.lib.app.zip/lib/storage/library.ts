export interface LibraryDocument {
  id: string;
  title: string;
  type:
    | "sermon"
    | "estudio"
    | "exegesis"
    | "devocional"
    | "griego"
    | "hebreo"
    | "ilustracion";

  content: string;

  createdAt: string;
}

const STORAGE_KEY = "pulpito-library";

export function getLibrary(): LibraryDocument[] {
  if (typeof window === "undefined") return [];

  const data = localStorage.getItem(STORAGE_KEY);

  if (!data) return [];

  return JSON.parse(data);
}

export function saveDocument(
  document: Omit<LibraryDocument, "id" | "createdAt">
) {
  if (typeof window === "undefined") return;

  const library = getLibrary();

  library.unshift({
    ...document,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
  });

  localStorage.setItem(STORAGE_KEY, JSON.stringify(library));
}