const es = {
  home: "Inicio",
  sermons: "Sermones",
  studies: "Estudios Bíblicos",
  exegesis: "Exégesis",
  devotionals: "Devocionales",
  greek: "Griego Bíblico",
  hebrew: "Hebreo Bíblico",
  illustrations: "Ilustraciones",
  library: "Biblioteca",
  settings: "Configuración",
  assistant: "Tu asistente ministerial inteligente",
};

export default es;