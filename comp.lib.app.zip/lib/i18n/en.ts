const en = {
  home: "Home",
  sermons: "Sermons",
  studies: "Bible Studies",
  exegesis: "Exegesis",
  devotionals: "Devotionals",
  greek: "Biblical Greek",
  hebrew: "Biblical Hebrew",
  illustrations: "Illustrations",
  library: "Library",
  settings: "Settings",
  assistant: "Your intelligent ministry assistant",
};

export default en;