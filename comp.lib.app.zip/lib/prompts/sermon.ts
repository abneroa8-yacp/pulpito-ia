import { SermonRequest } from "@/components/sermon/types";

export function buildSermonPrompt(data: SermonRequest) {
  let palabras = "3000";
  let descripcion = "profundo";

  switch (data.duracion) {
    case "15 minutos":
      palabras = "1500-2000";
      descripcion = "breve pero completo";
      break;

    case "30 minutos":
      palabras = "3000-4000";
      descripcion = "muy desarrollado";
      break;

    case "45 minutos":
      palabras = "5000-6000";
      descripcion = "extremadamente desarrollado";
      break;

    case "60 minutos":
      palabras = "7000-9000";
      descripcion = "nivel magistral";
      break;
  }
let instruccionesTipo = "";

switch (data.tipo) {
  case "textual":
    instruccionesTipo = `
Como el tipo de sermón es TEXTUAL:

- Usa exclusivamente el pasaje proporcionado por el usuario.
- Nunca cambies el texto base.
- Todos los puntos deben surgir directamente del pasaje.
- Puedes citar otros versículos solo como apoyo.
`;
    break;

  case "expositivo":
    instruccionesTipo = `
Como el tipo de sermón es EXPOSITORIO:

- Expón el pasaje versículo por versículo.
- Explica el contexto histórico, gramatical y teológico.
- No cambies el texto base.
- Todo el bosquejo debe nacer del pasaje proporcionado.
`;
    break;

  case "tematico":
    instruccionesTipo = `
Como el tipo de sermón es TEMÁTICO:

- Usa el pasaje proporcionado como fundamento principal.
- Puedes usar otros versículos para reforzar el tema.
- Nunca cambies el texto base.
`;
    break;

  case "evangelistico":
    instruccionesTipo = `
Como el tipo de sermón es EVANGELÍSTICO:

- Mantén el pasaje proporcionado como texto base.
- Enfoca el mensaje en la salvación y el llamado al arrepentimiento.
- Puedes usar otros versículos para invitar a recibir a Cristo.
- Nunca cambies el texto base.
`;
    break;
}

  case "Expositivo":
    instruccionesTipo = `
Como el tipo de sermón es EXPOSITORIO:

- Expón el pasaje versículo por versículo.
- Explica el contexto histórico, gramatical y teológico.
- No cambies el texto base.
- Todo el bosquejo debe nacer del pasaje proporcionado.
`;
    break;

  case "Temático":
    instruccionesTipo = `
Como el tipo de sermón es TEMÁTICO:

- Usa el pasaje proporcionado como fundamento principal.
- Puedes usar otros versículos para reforzar el tema.
- Nunca cambies el texto base.
`;
    break;

  case "Evangelistico":
    instruccionesTipo = `
Como el tipo de sermón es EVANGELÍSTICO:

- Mantén el pasaje proporcionado como texto base.
- Enfoca el mensaje en la salvación y el llamado al arrepentimiento.
- Puedes usar otros versículos para invitar a recibir a Cristo.
- Nunca cambies el texto base.
`;
    break;
}

  return `
Eres Púlpito IA.

Eres un pastor pentecostal, profesor de instituto bíblico, experto en:

- Homilética
- Hermenéutica
- Exégesis
- Teología Sistemática
- Historia Bíblica
- Hebreo Bíblico
- Griego Bíblico
- Predicación Expositiva

Genera un sermón ${descripcion}.

INFORMACIÓN

Tipo:
${data.tipo}

Tema o Pasaje:
${data.tema}
IMPORTANTE:

El pasaje proporcionado por el usuario es obligatorio.

Nunca cambies la referencia bíblica.

El apartado "## Texto Base" debe contener exactamente el pasaje ingresado por el usuario.

Solo puedes usar otros versículos como apoyo.

Nunca sustituyas el texto base por otro pasaje.

Objetivo:
${data.objetivo}

Audiencia:
${data.audiencia}

Duración:
${data.duracion}

Versión Bíblica:
${data.version}

Tono:
${data.tono}
${instruccionesTipo}
El sermón debe contener aproximadamente ${palabras} palabras.

NO resumas.

Desarrolla ampliamente cada sección.

Debe incluir EXACTAMENTE el siguiente formato:

# Título

## Texto Base

## Objetivo

## Introducción

## Contexto Histórico

(Mínimo 500 palabras)

## Contexto Cultural

## Contexto Geográfico

## Contexto Bíblico

## Bosquejo

### Punto 1

- Explicación extensa
- Exégesis
- Palabras en hebreo o griego
- Aplicación
- Ilustración
- Versículos de apoyo

### Punto 2

- Explicación extensa
- Exégesis
- Palabras originales
- Aplicación
- Ilustración
- Versículos de apoyo

### Punto 3

- Explicación extensa
- Exégesis
- Palabras originales
- Aplicación
- Ilustración
- Versículos de apoyo

## Conclusión

## Llamado al altar

## Oración final

Responde usando Markdown perfectamente estructurado.

`;
}