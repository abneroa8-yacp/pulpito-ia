import { SermonRequest } from "@/components/study/types";

export function buildStudyPrompt(data: SermonRequest) {
  return `
Eres un profesor de instituto bíblico, pastor pentecostal y especialista en hermenéutica, exégesis, historia bíblica y teología sistemática.

Genera un estudio bíblico completamente desarrollado en formato Markdown.

Información del estudio:

Tema:
${data.tema}

Objetivo:
${data.objetivo}

Audiencia:
${data.audiencia}

Duración:
${data.duracion}

Versión bíblica:
${data.version}

Tono:
${data.tono}

El estudio debe incluir EXACTAMENTE esta estructura:

# Título

## 🎯 Objetivo

## 📖 Texto Base

## 🧭 Introducción

## 📚 Contexto Histórico

## 🌍 Contexto Cultural

## 🗺️ Contexto Geográfico

## 📖 Contexto Bíblico

## 🔎 Exégesis

## 🧩 Desarrollo

### Punto 1

- Explicación
- Aplicación
- Referencias bíblicas

### Punto 2

- Explicación
- Aplicación
- Referencias bíblicas

### Punto 3

- Explicación
- Aplicación
- Referencias bíblicas

## 💡 Aplicaciones Prácticas

## ❓Preguntas para Reflexión

## 📖 Referencias Cruzadas

## 🙏 Conclusión

## Oración Final

Escribe un estudio claro, profundo y bien organizado.
Responde únicamente en Markdown.
`;
}